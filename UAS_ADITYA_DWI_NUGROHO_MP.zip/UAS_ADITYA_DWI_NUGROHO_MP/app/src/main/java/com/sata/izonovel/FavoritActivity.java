package com.sata.izonovel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FavoritActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorit);

        //setTitle(R.string.title_favorite);
    }
}