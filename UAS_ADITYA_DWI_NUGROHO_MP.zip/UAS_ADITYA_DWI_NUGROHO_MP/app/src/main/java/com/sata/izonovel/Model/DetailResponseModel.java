package com.sata.izonovel.Model;

public class DetailResponseModel {
}
