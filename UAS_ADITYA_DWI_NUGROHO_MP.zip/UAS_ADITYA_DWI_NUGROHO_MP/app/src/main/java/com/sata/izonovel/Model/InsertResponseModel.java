package com.sata.izonovel.Model;

public class InsertResponseModel {
    public String getInsertedId() {
        return insertedId;
    }

    public void setInsertedId(String insertedId) {
        this.insertedId = insertedId;
    }

    private  String insertedId;
}
